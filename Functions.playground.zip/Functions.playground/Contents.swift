import UIKit

var str = "Hello, playground"

//define one or more named, typed parameters (multiple parameters separated by commas)
//not required to define parameters
//optionally define return type  (with -> name of type returned)
//use a tuple type to return multiple values as one compound return value


//call function one and save as variable
var name: String
name = greet(person: "katie")
print (name)

//test function one from https://docs.swift.org/swift-book/LanguageGuide/Functions.html
func greet(person: String) -> String {
    let greeting = "Hello, " + person + "!"
    return greeting
}


//test function two
func display(no1: Int) -> Int {
   let a = no1
   return a
}
//call function two and save as variable
var num: Int
num = display(no1:2)
print (num)


//function with multiple parameters of different types from: https://docs.swift.org/swift-book/LanguageGuide/Functions.html
func greet(person: String, alreadyGreeted: Bool) -> String {
    if alreadyGreeted {
        return greet(person: person)
    } else {
        return greet(person: person)
    }
}
print(greet(person: "Tim", alreadyGreeted: true))


//function with no parameters from https://www.tutorialspoint.com/swift/swift_functions.htm
func votersname() -> String {
   return "Alice"
}
//call function
print(votersname())


//multiply two numbers from https://www.tutorialspoint.com/swift/swift_functions.htm
func mult(no1: Int, no2: Int) -> Int {
   return no1*no2
}

var sum: Int;
sum = mult(no1:2, no2:3)
print (sum)

//take in one string, separate by commas and return list of strings
func splitStr(fullStr: String) -> Array <String>{
    let strings = fullStr.components(separatedBy: ",")
    return strings
}

//save in array
var manyStrings: Array<String> = Array ()
manyStrings = splitStr(fullStr: "katie,bobby,ellie")

//print array
for string in manyStrings {
    print (string)
}


//example of recurison from https://www.programiz.com/swift-programming/recursion
func countDownToZero(num: Int) {
    print(num)
    if num > 0 {
        countDownToZero(num: num - 1)
    }
}
print("Countdown:")
countDownToZero(num:3)

//modified from https://docs.swift.org/swift-book/LanguageGuide/Functions.html
//Swift is pass-by-reference however,
//in order for a function to access a value, modify it and return the modified value the inout keyword needs to be used
//this forces the function become pass-by-value otherwise Swift is pass-by-reference
func swapTwoInts(a: inout Int, b: inout Int) {
    let temporaryA = a
    a = b
    b = temporaryA
}

var no = 2
var co = 10
print ("no = \(no), and co = \(co)")
//do not need to declare strings or literals as parameters
//'&' before the variable name refers that we are passing the argument to the in-out parameter

swapTwoInts(a: &no, b: &co)
print ("no = \(no), and co = \(co)")

//errors out: num1 is declared as a constant and can't be changed
/*func swap (num1: Int, num2: Int){
    let temporaryA = num1
    num1 = num2
    num2 = temporaryA
}
 */


