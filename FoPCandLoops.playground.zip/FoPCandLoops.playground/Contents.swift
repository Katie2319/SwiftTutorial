import UIKit

var num: Int
var yesOrNo: Bool
var emptyInt: Array<Int> = Array ()
var word: String

num = 23
word = "Katie"

yesOrNo = true
emptyInt.append(90)
emptyInt.append(100)


//if else statements(one condition)

if yesOrNo == true {
    print ("Its true!") }
else if yesOrNo == false  {
    print ("Its false!")
}
else {print ("Well.. something is wrong..") }

//NOT = '!' -- used as prefix
//AND = &&
//OR = ||

if yesOrNo != true {
    print ("Its false part2!") }
else if yesOrNo != false  {  //handles dangling else problem through using else ifs to prevent nesting ifs.
    print ("Its true part2!")
}
else {print ("Well.. something is wrong..") }


//if statements (multi-conditional)
var x: Int
    x = 11
if (x>10 && x < 20) {
    print ("x is between 10 and 20.")
}
if (x>10 || x<10){
    print ("x is not 10")
}


//for -in loop: iterate over array
for num in emptyInt{
    print (num)
}

//for loop with range
for index in 1...10{ //iterate over range of numbers *inclusive*
    print ("the index is going up: \(index)");
}


//while loop
while num > 10  {
    num -= 1
    print ("The number is now: \(num)")
    
}

var sum:Int
sum = 0
num = 20
print ("Loop 2 with continue")
//using continue to skip printing 15
while num > 10  {
    if (num == 15){
        num -= 1
        continue
    }
    print ("The number is now: \(num)")
    num -= 1
}

//repeat-while loop = Swift's version of the do-while loop
num = 30;
repeat {
    print ("we havent reached the number yet")
    num -= 1
}while num > 20

//switch - case
//NO IMPLICIT FALLTHROUGH: once first matching case is completed, the switch statement finishes execution, no break required
//if you desire a fallthrough to happen, add 'fallthrough' at the end of each case
//break statement often used to ignore a case --> such as a default
word = "bobby"
switch word {
case "ellie":
    print ("the middle child")
case "katie":
    print ("the oldest child")
    break
case "bobby":
    print ("the youngest child")
    fallthrough
default: //default required
   break
}


//testing short circuit evaluation
num = 3

if num < 5 || num > 20 {
   print ("Short circuit evaluation happens!")
}

if num < 5 && num > 20 {
   print ("Lets try with and")
}


//addressing dangling else problem (num = 3) w/last if as false (else printed)
if num < 5 {
    print ("the num is less than 5")
}

if num < 2 {
    print ("num is less than 2")
}

else {
 print ("it is not less than 2 and 5")
}


//dangling else but last if is true (else not printed)
if num < 5 {
    print ("the num is less than 5")
}

if num > 2 {
    print ("num is greater than 2")
}

else {
 print ("it is not between 2 and 5")
}
