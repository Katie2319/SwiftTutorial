//import UIKit
//import Swift //not necessary, automatically included in playground

print ("Hello World") //semicolons used if two statements on the same line

//declare multiple variables on one line
var i = 10.0, y=11.3, z = 12.5

print (i)

//declaring variables of different types
var num: Int
var word: String
var decimal: Float
var yesOrNo: Bool
var emptyInt: Array<Int> = Array ()
var emptyDict: [Int: String] = [:]

//use Unicode as variable name
var 😏: String
😏 = "smirk"
print (😏)

//Adding String and Int does not work
//var x: Int
//x = "5" + 6
//print (x)

//assigning values to different datatypes
num = 23
word = "Katie"
decimal = 23.9789
yesOrNo = true
emptyInt.append(90)
emptyInt.append(100)
emptyDict[1]="The Best:"
emptyDict[2]="Program"

//print different datatypes
print (num)
print (word)
print (decimal)
print (yesOrNo)
print (emptyInt)
print (emptyDict)

//these won't work becuase they combine two different datatypes 
//print (num+decimal)
//emptyInt.append("newAdd")
