import UIKit

var str = "Hello, playground"


//pass by value with primitives
var a: Int
var b: Int
a = 10
b = a
b += 1
print (a)//10
print (b)//11

//define global accessible variable
var name: String = "katie"

var x: Int
x = 2

print ("x =  \(x)")//2

var index:Int
index=1

for index in 1...5{
    var x: Int
    x=0
    //access global accessible variabl
    print ("Inside for loop name is: \(name)")
    // x  =0  each time, accessing x within loop
    print ("x =  \(x)")
}

//x is still = to 2, did not get changed in the for loop
//still referencing the x declared outside the loop
print ("After for loop: x =  \(x)")

for index in 1...5{
    //access global variable
    print ("Inside for loop name is: \(name)")
    x = x+1
    //x increases each time, accessing x inside loop
    print ("x =  \(x)")
}
//x = 7, when a new variable was not declared within the loop, the changes happened to the original x,
// and carried to outside the loop
print ("After for loop2: x =  \(x)")

func printNum(no1: Int) -> Int {
   var x: Int
   x=0
    //accessing global variable
   print ("Inside function name is: \(name)")
   return no1
}
printNum(no1: 5)
//x is still = to 7 (from previous loop
print ("After function1: x =  \(x)")

func printNum1(no1: Int) -> Int {
    x = x + 1
    //accessing global variable
    print ("Inside the function the title is \(Book.title)")
   print ("Inside function name is: \(name)")
   return no1
}

printNum1(no1: 5)

//x not redeclared inside function, so changes made to x now carry to value outside function
print ("After function2: x =  \(x)")



//global accessible variables using a struct
struct Book {
   static let title: String="Harry Potter"
   static let pageCount: Int = 356
}

//access variables
print ("Inside for loop name is: \(name)")
print ("the title is \(Book.title)")
print ("the page count is \(Book.pageCount)")


//test code
var charListA: Array<Character> = ["c", "a", "t"]
var charListB: Array<Character> = ["d", "o", "g"]

charListA=charListB

charListB[0] = "u"

print (charListA); //returns 'd' 'o' 'g'
print (charListB); //returns 'u' 'o' 'g'

